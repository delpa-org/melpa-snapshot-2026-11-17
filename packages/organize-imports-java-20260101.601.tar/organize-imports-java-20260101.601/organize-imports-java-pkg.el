;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organize-imports-java" "20260101.601"
  "Automatically organize imports in Java code."
  '((emacs "25.1")
    (f     "0.20.0")
    (s     "1.12.0")
    (dash  "2.14.1")
    (ht    "2.2"))
  :url "https://github.com/jcs-elpa/organize-imports-java"
  :commit "0782a1814104c556a39ac13f0d64f7a9d787899d"
  :revdesc "0782a1814104"
  :keywords '("convenience" "organize" "imports" "java" "eclipse")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
